# Building OpenLauncher

## 1. App
1. Open the folder in Android Studio (it generates the Gradle wrapper), sync, build `app`.
2. Put PRoot binaries (GPL-2.0, build from https://github.com/proot-me/proot for aarch64 Android) in
   `app/src/main/jniLibs/arm64-v8a/` named `libproot.so` and `libproot-loader.so`.

## 2. Runtime rootfs (you build and distribute it yourself, never inside the app)
A glibc aarch64 rootfs (e.g. Debian/Ubuntu arm64 via debootstrap) packed as `.tar.xz`, containing:
- **Box64**: build on an arm64 Linux host or in an arm64 chroot:
  `cmake .. -DARM_DYNAREC=ON -DCMAKE_BUILD_TYPE=RelWithDebInfo && make -j$(nproc)`, install into the rootfs.
- **Wine** (x86_64 build) at `/opt/wine`, so `/opt/wine/bin/wine64` exists (or edit `WINE_BIN`).
- **DXVK / VKD3D-Proton** DLLs: copy into each prefix's `system32` (x64) after first run, or script it.
- **Mesa Turnip**: build Mesa with the freedreno Vulkan driver for the KGSL backend
  (`-Dvulkan-drivers=freedreno -Dfreedreno-kmds=kgsl`); install the ICD json to
  `/usr/share/vulkan/icd.d/freedreno_icd.aarch64.json`. Follow the Mesa docs for Android cross-builds.
- Create `/home/xuser` and `/tmp`.

## 3. Display + input
The Wine process needs an X server at `<rootfs>/tmp/.X11-unix/X0`. Fork Winlator (https://github.com/brunodev85/winlator)
and reuse its Java XServer; add its view in `GameActivity` and implement `InputBridge` against its input handler.

## 4. Per-game config
`files/games/<id>/game_config.json` (see GameConfig.kt). Edit `env` to add any Wine/Box64 variable.
Logs: `files/games/<id>/last.log`.

## License
Use a GPL-3.0-compatible license (PRoot is GPL-2.0, Wine is LGPL). Do not bundle game files.
