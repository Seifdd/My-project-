plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "org.openlauncher"
    compileSdk = 34
    defaultConfig {
        applicationId = "org.openlauncher"
        minSdk = 26
        // targetSdk 28 keeps exec() from app data dirs allowed (same trick Winlator uses).
        targetSdk = 28
        versionCode = 1
        versionName = "0.1.0"
        ndk { abiFilters += "arm64-v8a" }
    }
    // Needed so libproot.so lands on disk as a real executable file.
    packaging { jniLibs { useLegacyPackaging = true } }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    lint { abortOnError = false }
    androidResources { noCompress += listOf("xz", "tzst", "zst") }
}

dependencies {
    implementation("org.apache.commons:commons-compress:1.26.2")
    implementation("org.tukaani:xz:1.9")
    implementation("com.github.luben:zstd-jni:1.5.6-3@aar")
}
