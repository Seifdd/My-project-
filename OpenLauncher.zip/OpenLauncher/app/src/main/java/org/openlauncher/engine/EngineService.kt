package org.openlauncher.engine

import android.app.*
import android.content.Intent
import android.os.IBinder
import org.openlauncher.data.GameRepository
import java.io.File
import kotlin.concurrent.thread

/** Foreground service that owns the Wine process so it survives activity changes. */
class EngineService : Service() {
    companion object {
        const val EXTRA_GAME_ID = "game_id"
        const val ACTION_STOP = "org.openlauncher.STOP"
        private const val CHANNEL = "engine"
    }

    @Volatile private var proc: Process? = null

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, flags: Int, startId: Int): Int {
        if (i?.action == ACTION_STOP) { killProcess(); stopSelf(); return START_NOT_STICKY }
        val id = i?.getStringExtra(EXTRA_GAME_ID)
        if (id == null) { stopSelf(); return START_NOT_STICKY }

        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CHANNEL, "Game engine", NotificationManager.IMPORTANCE_LOW))
        val stop = PendingIntent.getService(this, 0,
            Intent(this, EngineService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE)
        startForeground(1, Notification.Builder(this, CHANNEL)
            .setContentTitle("Game running")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .addAction(Notification.Action.Builder(null, "Stop", stop).build())
            .build())

        thread(name = "wine-$id") { runGame(id) }
        return START_NOT_STICKY
    }

    private fun runGame(id: String) {
        val repo = GameRepository(this)
        val cfg = repo.get(id)
        if (cfg == null) { stopSelf(); return }
        val log = File(repo.dir(id), "last.log")
        try {
            val pb = WineProcessBuilder(this, RuntimeInstaller(this), repo).build(cfg)
                .redirectOutput(ProcessBuilder.Redirect.to(log))
            proc = pb.start()
            proc?.waitFor()
        } catch (t: Throwable) {
            log.appendText("\nLauncher error: $t\n")
        } finally {
            proc = null
            stopSelf()
        }
    }

    private fun killProcess() {
        proc?.let { p ->
            p.destroy()
            thread { Thread.sleep(3000); if (p.isAlive) p.destroyForcibly() }
        }
    }

    override fun onDestroy() { killProcess(); super.onDestroy() }
}
