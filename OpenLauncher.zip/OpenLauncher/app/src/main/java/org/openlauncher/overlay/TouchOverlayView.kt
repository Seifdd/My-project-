package org.openlauncher.overlay

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PointF
import android.view.MotionEvent
import android.view.View
import kotlin.math.hypot
import kotlin.math.min

/**
 * Multi-touch overlay: on-screen buttons, a WASD virtual stick, and a free-look area
 * (any touch on the right half that misses a button becomes relative mouse movement).
 * Set [editMode] to drag buttons around; call profile.save(ctx) when done.
 */
class TouchOverlayView(
    ctx: Context,
    private val bridge: InputBridge,
    var profile: OverlayProfile,
) : View(ctx) {

    var editMode = false
    var lookSensitivity = 1.2f

    private val pressed = HashMap<Int, OverlayButton>()
    private val looks = HashMap<Int, PointF>()
    private val stickState = BooleanArray(4)                       // W A S D
    private val stickKeys = intArrayOf(Keysym.W, Keysym.A, Keysym.S, Keysym.D)
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val label = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; textAlign = Paint.Align.CENTER }

    private fun radius(b: OverlayButton) = b.r * min(width, height)

    override fun onDraw(c: Canvas) {
        for (b in profile.buttons) {
            val cx = b.x * width; val cy = b.y * height; val r = radius(b)
            fill.color = if (pressed.containsValue(b)) 0x88FFFFFF.toInt() else 0x44FFFFFF
            c.drawCircle(cx, cy, r, fill)
            label.textSize = r * 0.45f
            c.drawText(b.label, cx, cy + r * 0.15f, label)
        }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN -> {
                val i = e.actionIndex; press(e.getPointerId(i), e.getX(i), e.getY(i))
            }
            MotionEvent.ACTION_MOVE ->
                for (i in 0 until e.pointerCount) move(e.getPointerId(i), e.getX(i), e.getY(i))
            MotionEvent.ACTION_UP, MotionEvent.ACTION_POINTER_UP -> release(e.getPointerId(e.actionIndex))
            MotionEvent.ACTION_CANCEL -> (pressed.keys + looks.keys).toList().forEach(::release)
        }
        invalidate()
        return true
    }

    private fun press(id: Int, x: Float, y: Float) {
        val b = profile.buttons.firstOrNull {
            val grab = if (it.type == BtnType.STICK_WASD) 1.6f else 1f
            hypot(x - it.x * width, y - it.y * height) <= radius(it) * grab
        }
        if (b == null) { if (!editMode && x > width / 2f) looks[id] = PointF(x, y); return }
        pressed[id] = b
        if (editMode) return
        when (b.type) {
            BtnType.KEY -> bridge.key(b.code, true)
            BtnType.MOUSE -> bridge.mouseButton(b.code, true)
            BtnType.STICK_WASD -> updateStick(b, x, y)
        }
    }

    private fun move(id: Int, x: Float, y: Float) {
        val b = pressed[id]
        if (b != null) {
            if (editMode) { b.x = (x / width).coerceIn(0f, 1f); b.y = (y / height).coerceIn(0f, 1f) }
            else if (b.type == BtnType.STICK_WASD) updateStick(b, x, y)
            return
        }
        looks[id]?.let {
            bridge.mouseMove((x - it.x) * lookSensitivity, (y - it.y) * lookSensitivity)
            it.set(x, y)
        }
    }

    private fun release(id: Int) {
        looks.remove(id)
        val b = pressed.remove(id) ?: return
        if (editMode) return
        when (b.type) {
            BtnType.KEY -> bridge.key(b.code, false)
            BtnType.MOUSE -> bridge.mouseButton(b.code, false)
            BtnType.STICK_WASD -> for (i in 0..3) if (stickState[i]) { stickState[i] = false; bridge.key(stickKeys[i], false) }
        }
    }

    private fun updateStick(b: OverlayButton, x: Float, y: Float) {
        val dx = x - b.x * width; val dy = y - b.y * height; val dz = radius(b) * 0.3f
        val want = booleanArrayOf(dy < -dz, dx < -dz, dy > dz, dx > dz)
        for (i in 0..3) if (want[i] != stickState[i]) { stickState[i] = want[i]; bridge.key(stickKeys[i], want[i]) }
    }
}
