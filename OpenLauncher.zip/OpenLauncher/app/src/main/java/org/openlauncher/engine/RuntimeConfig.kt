package org.openlauncher.engine

/** Where the runtime (rootfs) is downloaded from. Put your GitHub Release asset URL in URL. */
object RuntimeConfig {
    const val URL = "https://github.com/Seifdd/My-project-/releases/download/untagged-4fb60e9e7f9018470d7a/rootfs-g7.1.6-1.1.tzst"
    const val SHA256 = "05d8ced367ce647da0d49138bcef85c646399ce6a0ba4faee92f59e32c6a0021"
}
