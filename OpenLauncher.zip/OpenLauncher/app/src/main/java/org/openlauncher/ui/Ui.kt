package org.openlauncher.ui

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

fun Context.dp(v: Int) = (v * resources.displayMetrics.density).toInt()

object Ui {
    val BG = 0xFF121212.toInt()
    val CARD = 0xFF1E1E22.toInt()
    val ACCENT = 0xFF4F8CFF.toInt()
    val DANGER = 0xFFE5484D.toInt()
    val TEXT = Color.WHITE
    val MUTED = 0xFF9A9AA5.toInt()

    fun rounded(color: Int, radiusDp: Int, ctx: Context) =
        GradientDrawable().apply { setColor(color); cornerRadius = ctx.dp(radiusDp).toFloat() }

    fun text(ctx: Context, s: String, sizeSp: Float = 15f, color: Int = TEXT, bold: Boolean = false) =
        TextView(ctx).apply {
            text = s; textSize = sizeSp; setTextColor(color)
            if (bold) setTypeface(typeface, Typeface.BOLD)
        }

    fun card(ctx: Context) = LinearLayout(ctx).apply {
        orientation = LinearLayout.VERTICAL
        background = rounded(CARD, 16, ctx)
        setPadding(ctx.dp(16), ctx.dp(14), ctx.dp(16), ctx.dp(14))
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = ctx.dp(12) }
    }

    fun button(ctx: Context, label: String, color: Int = ACCENT, onClick: () -> Unit) =
        Button(ctx).apply {
            text = label; isAllCaps = false; textSize = 15f; setTextColor(Color.WHITE)
            background = rounded(color, 12, ctx); minHeight = ctx.dp(48)
            stateListAnimator = null
            setOnClickListener { onClick() }
        }

    fun spacer(ctx: Context, h: Int = 8) = View(ctx).apply { layoutParams = LinearLayout.LayoutParams(-1, ctx.dp(h)) }
    fun center(v: TextView) = v.apply { gravity = Gravity.CENTER }
}
