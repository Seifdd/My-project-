package org.openlauncher.overlay

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

enum class BtnType { KEY, MOUSE, STICK_WASD }

/** Position (x, y) and radius (r) are fractions of the screen so layouts survive resolution changes. */
data class OverlayButton(
    val id: String, val label: String, val type: BtnType, val code: Int,
    var x: Float, var y: Float, val r: Float = 0.06f,
)

data class OverlayProfile(val name: String, val buttons: MutableList<OverlayButton>) {

    fun toJson() = JSONObject().apply {
        put("name", name)
        put("buttons", JSONArray().also { arr ->
            buttons.forEach { b -> arr.put(JSONObject().apply {
                put("id", b.id); put("label", b.label); put("type", b.type.name); put("code", b.code)
                put("x", b.x.toDouble()); put("y", b.y.toDouble()); put("r", b.r.toDouble())
            }) }
        })
    }

    fun save(ctx: Context) {
        val dir = File(ctx.filesDir, "overlays").apply { mkdirs() }
        File(dir, "$name.json").writeText(toJson().toString(2))
    }

    companion object {
        fun load(ctx: Context, name: String): OverlayProfile {
            val f = File(ctx.filesDir, "overlays/$name.json")
            if (!f.exists()) return default()
            return runCatching {
                val o = JSONObject(f.readText()); val a = o.getJSONArray("buttons")
                OverlayProfile(o.getString("name"), MutableList(a.length()) { i ->
                    val b = a.getJSONObject(i)
                    OverlayButton(b.getString("id"), b.getString("label"), BtnType.valueOf(b.getString("type")),
                        b.getInt("code"), b.getDouble("x").toFloat(), b.getDouble("y").toFloat(), b.getDouble("r").toFloat())
                })
            }.getOrElse { default() }
        }

        fun default() = OverlayProfile("default", mutableListOf(
            OverlayButton("move", "MOVE", BtnType.STICK_WASD, 0, 0.14f, 0.70f, 0.11f),
            OverlayButton("fire", "FIRE", BtnType.MOUSE, 1, 0.88f, 0.62f, 0.09f),
            OverlayButton("aim", "AIM", BtnType.MOUSE, 3, 0.76f, 0.76f, 0.07f),
            OverlayButton("jump", "JUMP", BtnType.KEY, Keysym.SPACE, 0.92f, 0.82f, 0.07f),
            OverlayButton("crouch", "CRCH", BtnType.KEY, Keysym.CTRL_L, 0.66f, 0.86f, 0.06f),
            OverlayButton("reload", "R", BtnType.KEY, Keysym.R, 0.70f, 0.55f, 0.055f),
            OverlayButton("sprint", "RUN", BtnType.KEY, Keysym.SHIFT_L, 0.28f, 0.50f, 0.06f),
            OverlayButton("use", "E", BtnType.KEY, Keysym.E, 0.36f, 0.82f, 0.055f),
            OverlayButton("esc", "ESC", BtnType.KEY, Keysym.ESC, 0.06f, 0.08f, 0.045f),
        ))
    }
}
