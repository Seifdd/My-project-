package org.openlauncher.engine

import android.content.Context
import org.apache.commons.compress.archivers.tar.TarArchiveInputStream
import org.apache.commons.compress.compressors.xz.XZCompressorInputStream
import org.apache.commons.compress.compressors.zstandard.ZstdCompressorInputStream
import java.io.BufferedInputStream
import java.io.File
import java.io.InputStream
import java.nio.file.Files
import java.nio.file.Paths

/**
 * Extracts a user-supplied aarch64 glibc rootfs (.tar.xz) containing box64, wine, DXVK, VKD3D and Turnip.
 * The app ships none of it; see docs/BUILDING.md for how to build your own.
 */
class RuntimeInstaller(private val ctx: Context) {
    val rootfs = File(ctx.filesDir, "rootfs")
    private val marker = File(rootfs, ".installed")
    private companion object { val BUNDLED = listOf("rootfs.tar.xz", "imagefs.tzst", "rootfs.tzst") }

    fun isInstalled() = marker.exists()

    /** True if app/src/main/assets/rootfs.tar.xz was bundled into the APK. */
    private fun bundledName() = BUNDLED.firstOrNull { n -> runCatching { ctx.assets.open(n).close(); true }.getOrDefault(false) }

    fun hasBundled() = bundledName() != null

    fun installBundled(onProgress: (Int) -> Unit = {}) =
        ctx.assets.open(bundledName() ?: error("No bundled runtime")).use { install(it, onProgress) }

    /** Detects .tar.xz vs .tzst (tar + zstd) by magic bytes, so the file name doesn't matter. */
    private fun decompress(src: InputStream): InputStream {
        val b = BufferedInputStream(src, 1 shl 16)
        b.mark(8)
        val h = ByteArray(6); val n = b.read(h); b.reset()
        fun at(i: Int, v: Int) = n > i && h[i] == v.toByte()
        return when {
            at(0, 0x28) && at(1, 0xB5) && at(2, 0x2F) && at(3, 0xFD) -> ZstdCompressorInputStream(b)
            at(0, 0xFD) && at(1, 0x37) && at(2, 0x7A) && at(3, 0x58) -> XZCompressorInputStream(b)
            else -> error("Unsupported archive: need .tar.xz or .tzst")
        }
    }

    fun install(src: InputStream, onProgress: (entries: Int) -> Unit = {}) {
        rootfs.deleteRecursively(); rootfs.mkdirs()
        val base = rootfs.toPath().toAbsolutePath().normalize()
        var count = 0
        TarArchiveInputStream(decompress(src)).use { tar ->
            var e = tar.nextTarEntry
            while (e != null) {
                val target = base.resolve(e.name).normalize()
                require(target.startsWith(base)) { "Blocked path traversal: ${e.name}" }
                val f = target.toFile()
                when {
                    e.isDirectory -> f.mkdirs()
                    e.isSymbolicLink -> {
                        f.parentFile?.mkdirs()
                        Files.deleteIfExists(target)
                        Files.createSymbolicLink(target, Paths.get(e.linkName))
                    }
                    e.isFile -> {
                        f.parentFile?.mkdirs()
                        f.outputStream().use { tar.copyTo(it, 1 shl 16) }
                        f.setReadable(true, false)
                        if (e.mode and 0b001_001_001 != 0) f.setExecutable(true, false)
                    }
                }
                if (++count % 500 == 0) onProgress(count)
                e = tar.nextTarEntry
            }
        }
        // Some archives wrap everything in an "imagefs/" folder: flatten it.
        val inner = File(rootfs, "imagefs")
        if (!File(rootfs, "usr").exists() && File(inner, "usr").exists()) {
            inner.listFiles()?.forEach { it.renameTo(File(rootfs, it.name)) }
            inner.delete()
        }
        File(rootfs, "tmp").mkdirs()
        marker.createNewFile()
    }
}
