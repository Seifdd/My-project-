package org.openlauncher.engine

import android.content.Context
import org.apache.commons.compress.archivers.tar.TarArchiveInputStream
import org.apache.commons.compress.compressors.xz.XZCompressorInputStream
import java.io.BufferedInputStream
import java.io.File
import java.io.InputStream
import java.nio.file.Files
import java.nio.file.Paths

/**
 * Extracts a user-supplied aarch64 glibc rootfs (.tar.xz) containing box64, wine, DXVK, VKD3D and Turnip.
 * The app ships none of it; see docs/BUILDING.md for how to build your own.
 */
class RuntimeInstaller(ctx: Context) {
    val rootfs = File(ctx.filesDir, "rootfs")
    private val marker = File(rootfs, ".installed")

    fun isInstalled() = marker.exists()

    fun install(src: InputStream, onProgress: (entries: Int) -> Unit = {}) {
        rootfs.deleteRecursively(); rootfs.mkdirs()
        val base = rootfs.toPath().toAbsolutePath().normalize()
        var count = 0
        TarArchiveInputStream(XZCompressorInputStream(BufferedInputStream(src, 1 shl 16))).use { tar ->
            var e = tar.nextTarEntry
            while (e != null) {
                val target = base.resolve(e.name).normalize()
                require(target.startsWith(base)) { "Blocked path traversal: ${e.name}" }
                val f = target.toFile()
                when {
                    e.isDirectory -> f.mkdirs()
                    e.isSymbolicLink -> {
                        f.parentFile?.mkdirs()
                        Files.deleteIfExists(target)
                        Files.createSymbolicLink(target, Paths.get(e.linkName))
                    }
                    e.isFile -> {
                        f.parentFile?.mkdirs()
                        f.outputStream().use { tar.copyTo(it, 1 shl 16) }
                        f.setReadable(true, false)
                        if (e.mode and 0b001_001_001 != 0) f.setExecutable(true, false)
                    }
                }
                if (++count % 500 == 0) onProgress(count)
                e = tar.nextTarEntry
            }
        }
        File(rootfs, "tmp").mkdirs()
        marker.createNewFile()
    }
}
