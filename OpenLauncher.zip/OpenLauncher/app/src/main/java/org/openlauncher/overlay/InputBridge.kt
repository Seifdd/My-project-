package org.openlauncher.overlay

import android.util.Log

/** Sink for synthesized input. Implement against your XServer fork's input handler. */
interface InputBridge {
    fun key(keysym: Int, down: Boolean)
    fun mouseButton(button: Int, down: Boolean)   // 1=left 2=middle 3=right
    fun mouseMove(dx: Float, dy: Float)           // relative, in screen pixels
}

/** X11 keysyms. */
object Keysym {
    const val W = 0x77; const val A = 0x61; const val S = 0x73; const val D = 0x64
    const val E = 0x65; const val R = 0x72; const val F = 0x66; const val Q = 0x71
    const val SPACE = 0x20; const val TAB = 0xff09; const val ENTER = 0xff0d
    const val ESC = 0xff1b; const val SHIFT_L = 0xffe1; const val CTRL_L = 0xffe3
}

/** Placeholder bridge for development. */
class LogInputBridge : InputBridge {
    override fun key(keysym: Int, down: Boolean) { Log.d("Input", "key 0x${keysym.toString(16)} $down") }
    override fun mouseButton(button: Int, down: Boolean) { Log.d("Input", "mouse $button $down") }
    override fun mouseMove(dx: Float, dy: Float) { Log.d("Input", "move $dx,$dy") }
}
