package org.openlauncher

import android.app.Activity
import android.os.Bundle
import android.widget.*
import org.openlauncher.data.GameConfig
import org.openlauncher.data.GameRepository
import org.openlauncher.ui.FilePicker
import org.openlauncher.ui.Ui
import org.openlauncher.ui.dp
import java.util.UUID

/** Add / edit a game. Every option is a dropdown or switch; nothing to type except name and args. */
class GameEditActivity : Activity() {
    companion object { const val EXTRA_ID = "id" }

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        window.statusBarColor = Ui.BG
        val repo = GameRepository(this)
        val old = intent.getStringExtra(EXTRA_ID)?.let { repo.get(it) }

        val form = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(24), dp(16), dp(32)) }
        setContentView(ScrollView(this).apply { setBackgroundColor(Ui.BG); addView(form) })
        form.addView(Ui.text(this, if (old == null) "إضافة لعبة" else "إعدادات اللعبة", 24f, bold = true))
        form.addView(Ui.spacer(this, 16))

        fun label(t: String) = form.addView(Ui.text(this, t, 13f, Ui.MUTED).apply { setPadding(0, dp(12), 0, dp(4)) })
        fun input(hint: String, v: String) = EditText(this).apply {
            setText(v); this.hint = hint; setTextColor(Ui.TEXT); setHintTextColor(Ui.MUTED)
            background = Ui.rounded(Ui.CARD, 12, this@GameEditActivity); setPadding(dp(14), dp(12), dp(14), dp(12))
        }.also { form.addView(it) }
        fun dropdown(title: String, options: List<String>, current: String): Spinner {
            label(title)
            return Spinner(this).apply {
                adapter = ArrayAdapter(this@GameEditActivity, android.R.layout.simple_spinner_dropdown_item, options)
                setSelection(options.indexOf(current).coerceAtLeast(0))
                background = Ui.rounded(Ui.CARD, 12, this@GameEditActivity)
            }.also { form.addView(it) }
        }

        label("اسم اللعبة")
        val name = input("مثال: My Game", old?.name ?: "")

        label("ملف التشغيل (exe)")
        var exe = old?.exePath ?: ""
        val exeView = Ui.text(this, exe.ifEmpty { "لم يتم الاختيار" }, 13f, Ui.ACCENT)
        form.addView(exeView)
        form.addView(Ui.spacer(this, 6))
        form.addView(Ui.button(this, "استعراض الملفات") {
            FilePicker(this) { exe = it; exeView.text = it }.show()
        })

        val res = dropdown("الدقة (أقل = أسرع)", listOf("960x540", "1280x720", "1600x900", "1920x1080"), old?.resolution ?: "1280x720")
        val preset = dropdown("وضع المعالج: performance أسرع، stable أكثر ثباتًا", listOf("performance", "stable"), old?.box64Preset ?: "performance")
        val dx = dropdown("DirectX: dxvk لـ DX9/10/11، vkd3d لـ DX12", listOf("dxvk", "vkd3d", "none"), old?.dxWrapper ?: "dxvk")
        val gpu = dropdown("تعريف الرسوميات: turnip لمعالجات Snapdragon", listOf("turnip", "system"), old?.gpuDriver ?: "turnip")

        label("خيارات")
        val hud = Switch(this).apply { text = "إظهار FPS"; setTextColor(Ui.TEXT); isChecked = old?.dxvkHud ?: false }.also { form.addView(it) }
        label("وسائط التشغيل (اختياري)")
        val args = input("", old?.args ?: "")

        form.addView(Ui.spacer(this, 24))
        form.addView(Ui.button(this, "حفظ") {
            if (name.text.isBlank() || exe.isBlank()) {
                Toast.makeText(this, "أدخل الاسم واختر ملف exe", Toast.LENGTH_SHORT).show(); return@button
            }
            val c = (old ?: GameConfig(UUID.randomUUID().toString().take(8), "", "")).copy(
                name = name.text.toString().trim(), exePath = exe, args = args.text.toString().trim(),
                resolution = res.selectedItem as String, box64Preset = preset.selectedItem as String,
                dxWrapper = dx.selectedItem as String, gpuDriver = gpu.selectedItem as String, dxvkHud = hud.isChecked,
            )
            repo.save(c); finish()
        })
        form.addView(Ui.spacer(this, 8))
        form.addView(Ui.button(this, "إلغاء", 0xFF2C2C33.toInt()) { finish() })
    }
}
