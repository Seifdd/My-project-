package org.openlauncher

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.ActivityInfo
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.TextView
import android.widget.Toast
import com.winlator.xserver.ScreenInfo
import com.winlator.xserver.XServer
import com.winlator.xserver.XServerView
import org.openlauncher.data.GameConfig
import org.openlauncher.data.GameRepository
import org.openlauncher.engine.EngineService
import org.openlauncher.overlay.OverlayProfile
import org.openlauncher.overlay.TouchOverlayView
import org.openlauncher.overlay.XServerInputBridge
import org.openlauncher.ui.Ui
import org.openlauncher.ui.dp

class GameActivity : Activity() {
    companion object { const val EXTRA_GAME_ID = EngineService.EXTRA_GAME_ID }

    private lateinit var container: FrameLayout
    private var xServer: XServer? = null
    private var overlay: TouchOverlayView? = null

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        val cfg = intent.getStringExtra(EXTRA_GAME_ID)?.let { GameRepository(this).get(it) }
        if (cfg == null) {
            Toast.makeText(this, "خطأ: لم يتم العثور على اللعبة", Toast.LENGTH_SHORT).show()
            finish(); return
        }
        container = FrameLayout(this).also { setContentView(it) }

        try {
            start(cfg)
        } catch (e: Exception) {
            Toast.makeText(this, "فشل تشغيل خادم العرض: ${e.message}", Toast.LENGTH_LONG).show()
            finish()
        }
    }

    private fun start(cfg: GameConfig) {
        // 1) Display server. Constructor/start API comes from YOUR Winlator fork: adjust if it differs.
        val (w, h) = cfg.resolution.split("x").map { it.toInt() }
        val server = XServer(ScreenInfo(w, h)).also { xServer = it }
        container.addView(XServerView(this, server), FrameLayoutParams())

        // 2) Touch overlay -> X server input
        val ov = TouchOverlayView(this, XServerInputBridge(server), OverlayProfile.load(this, cfg.overlayProfile))
        overlay = ov
        container.addView(ov, FrameLayoutParams())

        // 3) Menu button
        container.addView(menuButton(), FrameLayout.LayoutParams(dp(44), dp(44), Gravity.TOP or Gravity.CENTER_HORIZONTAL)
            .apply { topMargin = dp(8) })

        // 4) Start your fork's X connector on <rootfs>/tmp/.X11-unix/X0 HERE, then launch Wine:
        startForegroundService(Intent(this, EngineService::class.java).putExtra(EXTRA_GAME_ID, cfg.id))
    }

    private fun FrameLayoutParams() = FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT)

    private fun menuButton() = TextView(this).apply {
        text = "☰"; textSize = 22f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
        background = Ui.rounded(0x66000000, 12, this@GameActivity)
        setOnClickListener { showMenu() }
    }

    private fun showMenu() {
        val ov = overlay
        val editLabel = if (ov?.editMode == true) "حفظ تخطيط الأزرار" else "تعديل أزرار اللمس"
        AlertDialog.Builder(this).setTitle("قائمة التحكم")
            .setItems(arrayOf(editLabel, "إيقاف اللعبة والخروج")) { _, i ->
                if (i == 0 && ov != null) {
                    if (ov.editMode) ov.profile.save(this)
                    ov.editMode = !ov.editMode; ov.invalidate()
                } else if (i == 1) finish()
            }.show()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() = showMenu()

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) @Suppress("DEPRECATION") window.decorView.setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or View.SYSTEM_UI_FLAG_FULLSCREEN or
                View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_LAYOUT_STABLE)
    }

    override fun onDestroy() {
        startService(Intent(this, EngineService::class.java).setAction(EngineService.ACTION_STOP))
        runCatching { xServer = null }   // call your fork's server stop/close here
        super.onDestroy()
    }
}
