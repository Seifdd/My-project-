package org.openlauncher

import android.app.Activity
import android.content.Intent
import android.content.pm.ActivityInfo
import android.os.Bundle
import android.view.View
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.WindowManager
import android.widget.FrameLayout
import org.openlauncher.data.GameRepository
import org.openlauncher.engine.EngineService
import org.openlauncher.overlay.*

class GameActivity : Activity() {
    companion object { const val EXTRA_GAME_ID = EngineService.EXTRA_GAME_ID }

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        @Suppress("DEPRECATION")
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or
            View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_LAYOUT_STABLE

        val id = intent.getStringExtra(EXTRA_GAME_ID) ?: return finish()
        val cfg = GameRepository(this).get(id) ?: return finish()

        val root = FrameLayout(this)
        // (1) Display layer: add your Winlator-derived XServer view here BEFORE the overlay,
        //     and start it before EngineService so <rootfs>/tmp/.X11-unix/X0 exists.
        // (2) Replace LogInputBridge with a bridge that forwards into that XServer's input handler.
        val bridge: InputBridge = LogInputBridge()
        root.addView(TouchOverlayView(this, bridge, OverlayProfile.load(this, cfg.overlayProfile)),
            FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT))
        setContentView(root)

        startForegroundService(Intent(this, EngineService::class.java).putExtra(EXTRA_GAME_ID, id))
    }

    override fun onDestroy() {
        startService(Intent(this, EngineService::class.java).setAction(EngineService.ACTION_STOP))
        super.onDestroy()
    }
}
