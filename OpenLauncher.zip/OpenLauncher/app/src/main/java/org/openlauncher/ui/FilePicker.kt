package org.openlauncher.ui

import android.app.Activity
import android.app.AlertDialog
import android.os.Environment
import java.io.File

/** Simple folder browser that lets the user pick a .exe; returns a rootfs-visible path (/sdcard/...). */
class FilePicker(private val act: Activity, private val onPick: (String) -> Unit) {
    private val root: File = Environment.getExternalStorageDirectory()

    fun show(dir: File = root) {
        val entries = dir.listFiles()
            ?.filter { !it.name.startsWith(".") && (it.isDirectory || it.extension.equals("exe", true)) }
            ?.sortedWith(compareBy({ !it.isDirectory }, { it.name.lowercase() })) ?: emptyList()
        val hasUp = dir.canonicalPath != root.canonicalPath
        val labels = (if (hasUp) listOf("⬆  ..") else emptyList()) +
            entries.map { if (it.isDirectory) "📁  ${it.name}" else "🎮  ${it.name}" }

        AlertDialog.Builder(act)
            .setTitle(dir.path.removePrefix(root.path).ifEmpty { "/" })
            .setItems(labels.toTypedArray()) { _, i ->
                val idx = if (hasUp) i - 1 else i
                if (idx < 0) { show(dir.parentFile ?: root); return@setItems }
                val f = entries[idx]
                if (f.isDirectory) show(f) else onPick("/sdcard" + f.path.removePrefix(root.path))
            }
            .setNegativeButton("إلغاء", null).show()
    }
}
