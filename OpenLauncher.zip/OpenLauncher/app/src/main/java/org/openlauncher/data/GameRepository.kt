package org.openlauncher.data

import android.content.Context
import org.json.JSONObject
import java.io.File

class GameRepository(ctx: Context) {
    val root = File(ctx.filesDir, "games").apply { mkdirs() }

    fun dir(id: String) = File(root, id)

    fun list(): List<GameConfig> =
        root.listFiles()?.mapNotNull { d ->
            runCatching { GameConfig.fromJson(JSONObject(File(d, "game_config.json").readText())) }.getOrNull()
        }?.sortedBy { it.name.lowercase() } ?: emptyList()

    fun get(id: String): GameConfig? = list().firstOrNull { it.id == id }

    fun save(c: GameConfig) {
        dir(c.id).mkdirs()
        File(dir(c.id), "game_config.json").writeText(c.toJson().toString(2))
    }

    fun delete(id: String) = dir(id).deleteRecursively()
}
