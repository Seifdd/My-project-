package org.openlauncher.engine

import android.content.Context
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest

/** Downloads the runtime, verifies SHA-256, installs it, then deletes the temporary file. */
class RuntimeDownloader(private val ctx: Context, private val installer: RuntimeInstaller) {

    fun isConfigured() = RuntimeConfig.URL.startsWith("https://")

    fun downloadAndInstall(onStatus: (String) -> Unit) {
        val tmp = File(ctx.cacheDir, "runtime.download").also { it.delete() }
        val md = MessageDigest.getInstance("SHA-256")
        val conn = (URL(RuntimeConfig.URL).openConnection() as HttpURLConnection).apply {
            connectTimeout = 15_000; readTimeout = 30_000; instanceFollowRedirects = true
        }
        try {
            check(conn.responseCode == 200) { "HTTP ${conn.responseCode}" }
            val total = conn.contentLengthLong
            conn.inputStream.use { input ->
                tmp.outputStream().use { out ->
                    val buf = ByteArray(1 shl 16)
                    var done = 0L; var last = 0L
                    while (true) {
                        val n = input.read(buf)
                        if (n < 0) break
                        out.write(buf, 0, n); md.update(buf, 0, n); done += n
                        if (done - last > 1_000_000) {
                            last = done
                            onStatus("تنزيل ${done shr 20} / ${if (total > 0) (total shr 20).toString() else "?"} MB")
                        }
                    }
                }
            }
            val hex = md.digest().joinToString("") { "%02x".format(it) }
            check(hex.equals(RuntimeConfig.SHA256, ignoreCase = true)) { "فشل التحقق من SHA-256، الملف غير مطابق" }
            onStatus("جارٍ الاستخراج...")
            tmp.inputStream().use { installer.install(it) { n -> onStatus("تم استخراج $n ملف") } }
        } finally {
            conn.disconnect(); tmp.delete()
        }
    }
}
