package org.openlauncher.data

import org.json.JSONObject

/** Per-game settings, persisted as game_config.json. */
data class GameConfig(
    val id: String,
    val name: String,
    val exePath: String,              // path as seen from inside the rootfs, e.g. /sdcard/Games/x/game.exe
    val args: String = "",
    val resolution: String = "1280x720",
    val box64Preset: String = "performance",   // performance | stable
    val dxWrapper: String = "dxvk",            // dxvk | vkd3d | none
    val gpuDriver: String = "turnip",          // turnip | system
    val dxvkHud: Boolean = false,
    val env: Map<String, String> = emptyMap(),
    val overlayProfile: String = "default",
) {
    fun toJson(): JSONObject = JSONObject().apply {
        put("id", id); put("name", name); put("exePath", exePath); put("args", args)
        put("resolution", resolution); put("box64Preset", box64Preset)
        put("dxWrapper", dxWrapper); put("gpuDriver", gpuDriver)
        put("dxvkHud", dxvkHud); put("env", JSONObject(env)); put("overlayProfile", overlayProfile)
    }

    companion object {
        fun fromJson(o: JSONObject): GameConfig {
            val envObj = o.optJSONObject("env")
            val env = envObj?.keys()?.asSequence()?.associateWith { envObj.getString(it) } ?: emptyMap()
            return GameConfig(
                id = o.getString("id"), name = o.getString("name"), exePath = o.getString("exePath"),
                args = o.optString("args", ""), resolution = o.optString("resolution", "1280x720"),
                box64Preset = o.optString("box64Preset", "performance"),
                dxWrapper = o.optString("dxWrapper", "dxvk"), gpuDriver = o.optString("gpuDriver", "turnip"),
                dxvkHud = o.optBoolean("dxvkHud", false), env = env,
                overlayProfile = o.optString("overlayProfile", "default"),
            )
        }
    }
}
