package org.openlauncher.overlay

import com.winlator.xserver.Pointer
import com.winlator.xserver.XKeycode
import com.winlator.xserver.XServer

/**
 * Adapter: our overlay -> Winlator XServer injection.
 * Method/enum names follow Winlator's XServer as I know it; check them against your fork.
 */
class XServerInputBridge(private val xServer: XServer) : InputBridge {

    override fun key(keysym: Int, down: Boolean) {
        val k = keycode(keysym) ?: return
        if (down) xServer.injectKeyPress(k, keysym) else xServer.injectKeyRelease(k)
    }

    override fun mouseButton(button: Int, down: Boolean) {
        val b = when (button) {
            1 -> Pointer.Button.BUTTON_LEFT
            2 -> Pointer.Button.BUTTON_MIDDLE
            else -> Pointer.Button.BUTTON_RIGHT
        }
        if (down) xServer.injectPointerButtonPress(b) else xServer.injectPointerButtonRelease(b)
    }

    override fun mouseMove(dx: Float, dy: Float) {
        xServer.injectPointerMoveDelta(dx.toInt(), dy.toInt())
    }

    private fun keycode(ks: Int): XKeycode? = when (ks) {
        Keysym.W -> XKeycode.KEY_W; Keysym.A -> XKeycode.KEY_A
        Keysym.S -> XKeycode.KEY_S; Keysym.D -> XKeycode.KEY_D
        Keysym.E -> XKeycode.KEY_E; Keysym.R -> XKeycode.KEY_R
        Keysym.F -> XKeycode.KEY_F; Keysym.Q -> XKeycode.KEY_Q
        Keysym.SPACE -> XKeycode.KEY_SPACE; Keysym.TAB -> XKeycode.KEY_TAB
        Keysym.ENTER -> XKeycode.KEY_ENTER; Keysym.ESC -> XKeycode.KEY_ESC
        Keysym.SHIFT_L -> XKeycode.KEY_SHIFT_L; Keysym.CTRL_L -> XKeycode.KEY_CTRL_L
        else -> null
    }
}
