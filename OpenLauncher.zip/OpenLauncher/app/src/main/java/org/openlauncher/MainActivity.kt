package org.openlauncher

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.os.Bundle
import android.widget.*
import org.openlauncher.data.GameConfig
import org.openlauncher.data.GameRepository
import org.openlauncher.engine.RuntimeInstaller
import java.util.UUID
import kotlin.concurrent.thread

class MainActivity : Activity() {
    private val REQ_RUNTIME = 1
    private lateinit var repo: GameRepository
    private lateinit var runtime: RuntimeInstaller
    private lateinit var list: ListView
    private lateinit var status: TextView
    private var games = emptyList<GameConfig>()

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        repo = GameRepository(this); runtime = RuntimeInstaller(this)
        requestPermissions(arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE), 0)

        status = TextView(this).apply { textSize = 14f; setPadding(32, 32, 32, 8) }
        val install = Button(this).apply {
            text = "Install runtime (.tar.xz)"
            setOnClickListener {
                startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("*/*"), REQ_RUNTIME)
            }
        }
        val add = Button(this).apply { text = "Add game"; setOnClickListener { addGameDialog() } }
        list = ListView(this).apply {
            setOnItemClickListener { _, _, pos, _ -> launch(games[pos]) }
            setOnItemLongClickListener { _, _, pos, _ -> confirmDelete(games[pos]); true }
        }
        setContentView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(status); addView(install); addView(add)
            addView(list, LinearLayout.LayoutParams(-1, 0, 1f))
        })
    }

    override fun onResume() { super.onResume(); refresh() }

    private fun refresh() {
        status.text = if (runtime.isInstalled()) "Runtime: installed" else "Runtime: not installed"
        games = repo.list()
        list.adapter = object : ArrayAdapter<GameConfig>(this, android.R.layout.simple_list_item_2, android.R.id.text1, games) {
            override fun getView(p: Int, v: android.view.View?, parent: android.view.ViewGroup): android.view.View {
                val row = super.getView(p, v, parent)
                row.findViewById<TextView>(android.R.id.text1).text = games[p].name
                row.findViewById<TextView>(android.R.id.text2).text = games[p].exePath
                return row
            }
        }
    }

    private fun launch(g: GameConfig) {
        if (!runtime.isInstalled()) { toast("Install a runtime first"); return }
        startActivity(Intent(this, GameActivity::class.java).putExtra(GameActivity.EXTRA_GAME_ID, g.id))
    }

    private fun addGameDialog() {
        val name = EditText(this).apply { hint = "Name" }
        val exe = EditText(this).apply { hint = "Exe path, e.g. /sdcard/Games/MyGame/game.exe" }
        AlertDialog.Builder(this).setTitle("Add game")
            .setView(LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL; setPadding(48, 16, 48, 0); addView(name); addView(exe)
            })
            .setPositiveButton("Save") { _, _ ->
                if (name.text.isBlank() || exe.text.isBlank()) return@setPositiveButton
                repo.save(GameConfig(UUID.randomUUID().toString().take(8), name.text.toString().trim(), exe.text.toString().trim()))
                refresh()
            }.setNegativeButton("Cancel", null).show()
    }

    private fun confirmDelete(g: GameConfig) {
        AlertDialog.Builder(this).setTitle("Delete ${g.name}?")
            .setMessage("Removes its config and Wine prefix, not your game files.")
            .setPositiveButton("Delete") { _, _ -> repo.delete(g.id); refresh() }
            .setNegativeButton("Cancel", null).show()
    }

    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        val uri = data?.data ?: return
        if (req != REQ_RUNTIME || res != RESULT_OK) return
        status.text = "Installing runtime..."
        thread {
            val msg = runCatching { contentResolver.openInputStream(uri)!!.use { runtime.install(it) { n -> runOnUiThread { status.text = "Extracted $n entries" } } } }
                .fold({ "Runtime installed" }, { "Install failed: ${it.message}" })
            runOnUiThread { toast(msg); refresh() }
        }
    }

    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_LONG).show()
}
