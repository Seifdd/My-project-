package org.openlauncher

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.widget.*
import org.openlauncher.data.GameConfig
import org.openlauncher.data.GameRepository
import org.openlauncher.engine.RuntimeInstaller
import org.openlauncher.ui.Ui
import org.openlauncher.ui.dp
import kotlin.concurrent.thread

class MainActivity : Activity() {
    private val REQ_RUNTIME = 1
    private lateinit var repo: GameRepository
    private lateinit var runtime: RuntimeInstaller
    private lateinit var content: LinearLayout
    private var setupStatus: TextView? = null

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        repo = GameRepository(this); runtime = RuntimeInstaller(this)
        requestPermissions(arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE), 0)
        window.statusBarColor = Ui.BG

        content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(24), dp(16), dp(100)) }
        val scroll = ScrollView(this).apply { setBackgroundColor(Ui.BG); addView(content) }

        val fab = TextView(this).apply {
            text = "+"; textSize = 30f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Ui.ACCENT) }
            elevation = dp(6).toFloat()
            setOnClickListener { startActivity(Intent(this@MainActivity, GameEditActivity::class.java)) }
        }
        setContentView(FrameLayout(this).apply {
            addView(scroll)
            addView(fab, FrameLayout.LayoutParams(dp(60), dp(60), Gravity.BOTTOM or Gravity.END).apply { setMargins(0, 0, dp(20), dp(24)) })
        })
    }

    override fun onResume() { super.onResume(); render() }

    private fun render() {
        content.removeAllViews()
        content.addView(Ui.text(this, "مكتبة الألعاب", 26f, bold = true))
        content.addView(Ui.spacer(this, 16))

        // Runtime card
        val setup = Ui.card(this)
        if (runtime.isInstalled()) {
            setup.addView(Ui.text(this, "✔  المحرك جاهز", 15f, 0xFF4CD964.toInt(), true))
        } else {
            setup.addView(Ui.text(this, "الخطوة 1: تثبيت المحرك", 16f, bold = true))
            setup.addView(Ui.text(this, "اختر ملف المحرك (rootfs.tar.xz) الذي جهّزته. يحتاج تثبيتًا لمرة واحدة.", 13f, Ui.MUTED))
            setupStatus = Ui.text(this, "", 13f, Ui.ACCENT).also { setup.addView(it) }
            setup.addView(Ui.spacer(this, 8))
            setup.addView(Ui.button(this, "اختيار ملف المحرك") {
                startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("*/*"), REQ_RUNTIME)
            })
        }
        content.addView(setup)

        val games = repo.list()
        if (games.isEmpty()) {
            content.addView(Ui.card(this).apply {
                addView(Ui.text(this@MainActivity, "لا توجد ألعاب بعد", 16f, bold = true))
                addView(Ui.text(this@MainActivity, "اضغط زر + لإضافة لعبة تملك ملفاتها.", 13f, Ui.MUTED))
            })
        }
        games.forEach { content.addView(gameCard(it)) }
    }

    private fun gameCard(g: GameConfig): LinearLayout {
        val row = Ui.card(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val badge = Ui.center(Ui.text(this, g.name.take(1).uppercase(), 20f, Color.WHITE, true)).apply {
            background = Ui.rounded(Ui.ACCENT, 12, this@MainActivity)
            layoutParams = LinearLayout.LayoutParams(dp(48), dp(48)).apply { marginEnd = dp(14) }
        }
        val info = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
            addView(Ui.text(this@MainActivity, g.name, 17f, bold = true))
            addView(Ui.text(this@MainActivity, "${g.resolution} • ${g.dxWrapper.uppercase()} • ${g.box64Preset}", 12f, Ui.MUTED))
        }
        val edit = Ui.text(this, "⚙", 22f, Ui.MUTED).apply {
            setPadding(dp(12), dp(8), dp(4), dp(8))
            setOnClickListener { startActivity(Intent(this@MainActivity, GameEditActivity::class.java).putExtra(GameEditActivity.EXTRA_ID, g.id)) }
        }
        row.addView(badge); row.addView(info); row.addView(edit)
        row.setOnClickListener { launch(g) }
        row.setOnLongClickListener { confirmDelete(g); true }
        return row
    }

    private fun launch(g: GameConfig) {
        if (!runtime.isInstalled()) { toast("ثبّت المحرك أولًا"); return }
        startActivity(Intent(this, GameActivity::class.java).putExtra(GameActivity.EXTRA_GAME_ID, g.id))
    }

    private fun confirmDelete(g: GameConfig) {
        AlertDialog.Builder(this).setTitle("حذف ${g.name}؟")
            .setMessage("يحذف الإعدادات وبيئة Wine الخاصة بها، ولا يحذف ملفات اللعبة.")
            .setPositiveButton("حذف") { _, _ -> repo.delete(g.id); render() }
            .setNegativeButton("إلغاء", null).show()
    }

    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        val uri = data?.data ?: return
        if (req != REQ_RUNTIME || res != RESULT_OK) return
        setupStatus?.text = "جارٍ التثبيت... لا تغلق التطبيق"
        thread {
            val msg = runCatching {
                contentResolver.openInputStream(uri)!!.use { runtime.install(it) { n -> runOnUiThread { setupStatus?.text = "تم استخراج $n ملف" } } }
            }.fold({ "تم تثبيت المحرك" }, { "فشل التثبيت: ${it.message}" })
            runOnUiThread { toast(msg); render() }
        }
    }

    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_LONG).show()
}
