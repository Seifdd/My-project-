package org.openlauncher.engine

import android.content.Context
import org.openlauncher.data.GameConfig
import org.openlauncher.data.GameRepository
import java.io.File

object Box64Presets {
    val presets: Map<String, Map<String, String>> = mapOf(
        "performance" to mapOf(
            "BOX64_DYNAREC_BIGBLOCK" to "3", "BOX64_DYNAREC_SAFEFLAGS" to "0",
            "BOX64_DYNAREC_STRONGMEM" to "0", "BOX64_DYNAREC_FASTNAN" to "1",
            "BOX64_DYNAREC_FASTROUND" to "1", "BOX64_DYNAREC_CALLRET" to "1",
        ),
        "stable" to mapOf(
            "BOX64_DYNAREC_BIGBLOCK" to "0", "BOX64_DYNAREC_SAFEFLAGS" to "2",
            "BOX64_DYNAREC_STRONGMEM" to "1", "BOX64_DYNAREC_FASTNAN" to "0",
            "BOX64_DYNAREC_FASTROUND" to "0", "BOX64_DYNAREC_CALLRET" to "0",
        ),
    )
}

/**
 * Builds the host-side command: libproot.so -> box64 -> wine64 explorer /desktop=... game.exe
 * Paths after "-b" / "--rootfs" are resolved by PRoot, i.e. they are rootfs-internal.
 */
class WineProcessBuilder(
    private val ctx: Context,
    private val runtime: RuntimeInstaller,
    private val repo: GameRepository,
) {
    companion object {
        const val WINE_BIN = "/opt/wine/bin/wine64"   // adjust to your rootfs layout
    }

    fun build(c: GameConfig): ProcessBuilder {
        val native = ctx.applicationInfo.nativeLibraryDir
        val prootTmp = File(ctx.cacheDir, "proot").apply { mkdirs() }

        val env = linkedMapOf(
            "HOME" to "/home/xuser", "USER" to "xuser", "LANG" to "en_US.UTF-8",
            "PATH" to "/opt/wine/bin:/usr/local/bin:/usr/bin:/bin",
            "TMPDIR" to "/tmp", "DISPLAY" to ":0",
            "WINEPREFIX" to "/games/${c.id}/prefix", "WINEDEBUG" to "-all",
            "BOX64_NOBANNER" to "1", "BOX64_LOG" to "0",
        )
        env += Box64Presets.presets[c.box64Preset] ?: Box64Presets.presets.getValue("performance")

        when (c.dxWrapper) {
            "dxvk" -> env["WINEDLLOVERRIDES"] = "d3d8,d3d9,d3d10core,d3d11,dxgi=n,b"
            "vkd3d" -> env["WINEDLLOVERRIDES"] = "d3d12,d3d12core=n,b"
        }
        if (c.gpuDriver == "turnip") {
            env["VK_ICD_FILENAMES"] = "/usr/share/vulkan/icd.d/freedreno_icd.aarch64.json"
            env["TU_DEBUG"] = "noconform"
        }
        if (c.dxvkHud) env["DXVK_HUD"] = "fps"
        env += c.env   // per-game overrides win

        val cmd = mutableListOf(
            "$native/libproot.so", "--kill-on-exit", "--link2symlink",
            "--rootfs=${runtime.rootfs.absolutePath}",
            "-b", "/dev", "-b", "/proc", "-b", "/sys",
            "-b", "${repo.root.absolutePath}:/games",
            "-b", "/storage/emulated/0:/sdcard",
            "-w", "/home/xuser",
            "/usr/bin/env",
        )
        env.forEach { (k, v) -> cmd += "$k=$v" }
        cmd += listOf("box64", WINE_BIN, "explorer", "/desktop=shell,${c.resolution}", c.exePath)
        if (c.args.isNotBlank()) cmd += c.args.trim().split(Regex("\\s+"))

        return ProcessBuilder(cmd).apply {
            directory(ctx.filesDir)
            environment().apply {
                put("PROOT_TMP_DIR", prootTmp.absolutePath)
                put("PROOT_LOADER", "$native/libproot-loader.so")
            }
            redirectErrorStream(true)
        }
    }
}
